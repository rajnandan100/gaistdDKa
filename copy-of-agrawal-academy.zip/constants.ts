
export const GRADE_LEVELS = [
    "Elementary School",
    "Middle School",
    "High School",
    "University",
    "Graduate Level",
];
