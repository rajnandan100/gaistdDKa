
export interface Module {
  title: string;
  description: string;
}

export enum AppStep {
  TOPIC_SELECTION,
  MODULE_SELECTION,
  CONTENT_VIEW,
}
